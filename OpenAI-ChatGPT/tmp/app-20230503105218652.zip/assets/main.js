const client = ZAFClient.init();

async function updateSummary() {
    const convo = await getTicketConvo();
    document.getElementById('progressbar').style.width = '15%';
    const prompt = await getPrompt(convo);
    document.getElementById('progressbar').style.width = '30%';
    const summary = await getSummary(prompt);
    document.getElementById('progressbar').style.width = '70%';
    const container = document.getElementById("container");

    container.innerText = summary;
    container.innerText = 'lagarticha baia'


    document.getElementById('progressbar').style.width = '100%';



}

async function getTicketConvo() {
    const ticketConvo = await client.get("ticket.conversation");
    return JSON.stringify(ticketConvo["ticket.conversation"]);
}

async function getPrompt(convo) {
    return `
Detect the language and write your answer in the same language what you read.
Summarize the following customer service interaction.
Detect the customer's sentiment and extract any key dates,
places, or products in the following three topics.

Summary:

Customer sentiment:

Key Information:

${convo}`;
}

async function getSummary(prompt) {
    const options = {
        url: "https://api.openai.com/v1/chat/completions",
        type: "POST",
        contentType: "application/json",
        headers: {
            Authorization: "Bearer {{setting.openAiApiToken}}",
        },
        data: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: prompt }],
        }),
        secure: true,
    };
    const response = await client.request(options);

    return response.choices[0].message.content.trim();
}

client.on("app.registered", () => {
    client.invoke("resize", { width: "100%", height: "400px" });
    updateSummary();
});

client.on("ticket.conversation.changed", () => {
    updateSummary();
});

document.getElementById('regenerate').onclick = function (event) {
    updateSummary();
}